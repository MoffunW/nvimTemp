---@type ChadrcConfig 
 local M = {}
 M.mappings = require 'custom.mappings'
 M.ui = {theme = 'onenord'}
 return M


local M = {}

local map = require('core.utils').map
-- In order to disable a default keymap, use
M.disabled = {
  n = {
      ["<leader>h"] = "",
      ["<C-a>"] = "",
      ["<C-c>"] = "",
      ["<C-v>"] = "",
  }
}


-- Moving faster
map("n", "J", "5j")
map("n", "K", "5k")

-- Quit insert mode
map("i", "jk", "<ESC>")

-- Formatting
map("n", "<", "<<") map("n", ">", ">>")
map("v", "<", "<<")
map("v", ">", ">>")

-- Redo
map("n", "<C-z>", "u")

-- Your custom mappings
M.abc = {
  n = {
     ["<C-p>"] = {":Telescope find_files <CR>", "Telescope Files"}
  };

  i = {
     ["jk"] = { "<ESC>", "escape insert mode" , opts = { nowait = true }},
    -- ...
  }
}

return M


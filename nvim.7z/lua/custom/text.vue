<template>
  <div class="create">
    <div v-if="modalType === 'create'" class="create__header">
      <div class="create__title">Создание совещания</div>
    </div>
    <div class="create__body">
      <div class="details create_column">
        <div v-if="modalType === 'view' || isOutdated" class="pb-20 view__title view__text">
          <div class="named-input__label">Тема совещания</div>
          <div class="named-input__text">{{ title }}</div>
        </div>
        <div v-else class="pb-20 named-input">
          <p class="named-input__label">Тема совещания <span class="required-field">*</span></p>
          <input class="modal-input" v-model="title" type="text" />
        </div>

        <div class="pb-20 space-between datetime">
          <div class="named-input">
            <div class="named-input__label">
              Дата и время
              <span v-if="modalType !== 'view'" class="required-field">*</span>
            </div>
            <el-date-picker
              v-if="modalType !== 'view' && !isOutdated"
              v-model="dateSelected"
              @change="resetTimes"
              :picker-options="{
                firstDayOfWeek: 1,
                disabledDate: disabledDates
              }"
            ></el-date-picker>
            <div v-if="modalType === 'view' || isOutdated" class="view__datetime view__text">
              <!-- Check -->
              <div class="view__date">{{ formatPeriod()[0] }}</div>
              <div class="view__divider"></div>
              <div class="view__time">{{ formatPeriod()[1] }}</div>
            </div>
            <!-- !TODO Period with time -->
          </div>
          <div v-if="modalType !== 'view' && !isOutdated" class="time">
            <el-time-picker
              format="HH-mm"
              v-model="timeFrom"
              @change="timeTo = null"
              :disabled="!dateSelected"
              :picker-options="{
                selectableRange: selectableTimes()[0]
              }"
              class="time__input"
            ></el-time-picker>
            <div class="time__divider"></div>
            <el-time-picker
              format="HH-mm"
              v-model="timeTo"
              :disabled="!timeFrom"
              :picker-options="{
                selectableRange: selectableTimes()[1]
              }"
              class="time__input"
            ></el-time-picker>
          </div>
        </div>
        <div v-if="modalType !== 'view' && !isOutdated" class="named-input pb-20">
          <div class="named-input__label">Описание</div>
          <el-input
            v-if="modalType !== 'view' && !isOutdated"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 5 }"
            resize="none"
            v-model="description"
            class="named-input__input named-input_textarea"
          ></el-input>
        </div>
        <div v-if="modalType === 'view' || isOutdated" class="named-input view__text pb-20">
          <div class="named-input__label">Описание</div>
          <div v-if="meeting.description !== ''" class="view__text named-input__text">
            {{ meeting.description }}
          </div>
          <div v-else class="empty">Отсутствует</div>
        </div>
        <div
          v-if="modalType === 'view' || isOutdated"
          class="pb-20 view__connection-link view__text"
        >
          <div style="display: block" class="named-input__label">
            Ссылка на подключение
          </div>
          <a v-if="meeting.link_meeting !== ''" :href="meeting.link_meeting">{{
            meeting.link_meeting
          }}</a>
          <div v-else class="empty">Ссылка не была добавлена</div>
        </div>
        <div v-else class="pb-20 named-input">
          <p class="named-input__label">
            Ссылка для подключение
            <a
              v-show="connectionLink"
              class="modal-link modal-link--connection"
              :href="connectionLink"
              target="_blank"
              >Открыть<el-icon class="el-icon-link modal-link-icon"></el-icon
            ></a>
          </p>
          <input class="modal-input" v-model="connectionLink" type="text" />
        </div>
        <div v-if="modalType === 'view' || isOutdated" class="view__text">
          <div class="named-input__label">Место проведения</div>
          <div class="named-input__text">
            {{ meeting.place ? meeting.place : null }}
          </div>
          <!-- !TODO поле link_meeting в место проведения -->
          <div v-if="!meeting.place" class="empty">
            Место проведения не указано
          </div>
        </div>
        <div v-else class="pb-20 named-input">
          <p class="named-input__label">Место проведения</p>
          <input
            class="modal-input"
            v-if="modalType !== 'view' && !isOutdated"
            v-model="meetingPlace"
            type="text"
          />
        </div>
        <div v-if="modalType !== 'view' && !isOutdated" class="named-input pb-20">
          <div class="named-input__label">Напоминание</div>
          <el-select v-model="remindMode">
            <el-option
              v-for="mode in remindModes"
              :key="mode.value"
              :value="mode.value"
              :label="mode.name"
            >
              {{ mode.name }}
            </el-option>
          </el-select>
        </div>
        <div
          v-if="modalType === 'edit' && !isOutdated && initialRepeatMode !== 0"
          class="named-input pb-20"
        >
          <div class="named-input__label">Изменить совещание</div>
          <el-switch v-model="isEditGroup" active-text="Все последующие" inactive-text="Только это">
          </el-switch>
        </div>
        <div
          v-if="
            (initialRepeatMode === 0 && modalType === 'edit') ||
              (!isOutdated && (modalType === 'create' || isEditGroup))
          "
          class="named-input pb-20"
        >
          <div :class="[repeatMode !== 0 && repeatMode !== 6 && repeatMode !== null ? 'row' : '']">
            <div class="named-input__wrapper">
              <div class="named-input__label">Повторять совещание</div>
              <el-select
                :disabled="!timeTo"
                @click="checkCustomSettings"
                @focus="checkCustomSettings"
                @change="checkCustomSettings"
                v-model="repeatMode"
              >
                <el-option
                  v-for="mode in repeatModes"
                  :key="mode.value"
                  :value="mode.value"
                  :label="mode.name"
                >
                  {{ mode.name }}
                </el-option>
              </el-select>
            </div>
            <div
              v-if="!isOutdated && modalType !== 'view' && repeatMode && repeatMode !== 6"
              class="named-input__wrapper"
              style="margin-left: 20px"
            >
              <div class="named-input__label">
                Повторять до <span class="required-field">*</span>
              </div>
              <el-date-picker
                v-model="repeatEndCycle"
                placeholder="Без окончания"
                :value-format="'yyyy-MM-ddTHH:mm:ss.sssZ'"
                :picker-options="{
                  firstDayOfWeek: 1,
                  disabledDate: disabledRepeatDates
                }"
              ></el-date-picker>
            </div>
          </div>
        </div>
      </div>

      <div class="users create_column">
        <div v-if="modalType !== 'view' && !isOutdated" class="cell">
          <div class="users__label">Добавление участников</div>
          <div class="users-list">
            <div class="users-list__header">
              <div class="row gap">
                <el-input v-model="searchUserValue"
                  ><i slot="prefix" class="el-input__icon el-icon-search"></i
                ></el-input>
              </div>
            </div>
            <div class="users-list__body">
              <div
                class="users-list__user"
                :class="selectedUserIds.includes(user.id) ? 'users-list__user--selected' : ''"
                @click="onUserClick(user)"
                v-for="user in filteredUsers()"
                :key="user.id"
              >
                <img
                  :src="
                    user.image
                      ? 'https://mirtek.info:22334/uploads/' + user.image
                      : 'https://mirtek.info:22334/portal/img/blank-face-person.83c30568.png'
                  "
                  :alt="user.name + ' ' + user.surname"
                  class="users-list__photo"
                />
                <div class="users-list__info">
                  <div class="users-list__name">
                    {{ user.name + ' ' + user.surname }}
                  </div>

                  <div class="users-list__place">{{ user.affiliate }} / {{ user.department }}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div :class="modalType === 'view' ? 'cell_height' : ''" class="cell">
          <div class="users__label">Список участников <span class="required-field">*</span></div>
          <div class="selected">
            <div class="selected__body">
              <div
                :class="modalType === 'view' ? 'selected__user--view' : ''"
                class="selected__user"
                v-for="user in selectedUsers"
                :key="user.id"
              >
                <i
                  v-if="modalType !== 'view' && !isOutdated"
                  @click="onUserClick(user)"
                  class="el-icon-circle-close selected__close"
                ></i>
                <img
                  :src="
                    user.image
                      ? 'https://mirtek.info:22334/uploads/' + user.image
                      : 'https://mirtek.info:22334/portal/img/blank-face-person.83c30568.png'
                  "
                  :alt="user.surname + ' ' + user.name"
                  class="selected__photo"
                />
                <div class="selected__name">
                  <div class="selected__name-item">{{ user.surname }}</div>
                  <div class="selected__name-item">{{ user.name }}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="materials create_column">
        <div v-if="modalType !== 'view' && !isOutdated" class="upload">
          <div class="named-input__label">Добавление файлов</div>
          <div
            class="upload__dropdown"
            @dragenter.prevent.stop="dragenterHandler"
            @dragover.prevent.stop="dragenterHandler"
            @dragleave.prevent.stop="dragleaveHandler"
            @dragend.prevent.stop="dragleaveHandler"
            @drop.prevent.stop="handleFilesUpload"
            :class="{ dragover: isFileDrag }"
            @click="clickOnUpload"
          >
            <input
              ref="actionsUpload"
              style="display: none"
              type="file"
              @input="handleFilesUpload"
              multiple
            />
            <i class="el-icon-upload upload__icon"></i>
            <div class="upload__text">
              Перетащите файл или
              <p class="upload__text-click">нажмите сюда</p>
            </div>
            <div class="upload__notice">Файл не должен превышать 5 Мб.</div>
          </div>
        </div>
        <div
          v-if="isOutdated || modalType === 'view' || files.length > 0"
          class="named-input__label"
        >
          Список файлов
        </div>
        <div
          v-if="modalType === 'view' && files.length === 0"
          class="files--empty empty view__text"
        >
          Файлы не были добавлены
        </div>
        <div v-if="files.length > 0" class="files">
          <div v-for="(file, index) in files" :key="index" class="files__file">
            <i class="el-icon-document files__icon"></i>
            <div @click="downloadFile(file)" class="files__filename">
              <div class="files__filename-text">
                {{ file.name }}
              </div>
            </div>
            <i
              @click="removeFile(file)"
              v-if="modalType !== 'view' && !isOutdated"
              class="el-icon-circle-close files__delete"
            ></i>
          </div>
        </div>
        <div v-if="modalType !== 'view' && !isOutdated" class="named-input__label">
          Добавить ссылки
        </div>
        <div v-if="modalType === 'view' || isOutdated" class="named-input__label">
          Cписок ссылок
        </div>
        <div v-if="modalType === 'view' && linksList.length === 0" class="empty view__text">
          Ссылки не были добавлены
        </div>
        <div class="links">
          <div v-if="modalType !== 'view' && !isOutdated" class="links__row row">
            <input @keyup.enter="addLinkItem" v-model="linkValue" class="links__input" />
            <button class="links__add" :disabled="!linkValue" @click="addLinkItem">
              Прикрепить
            </button>
          </div>
          <div class="links__list">
            <div v-for="(link, index) in linksList" :key="index" class="links__item">
              <i
                v-if="modalType !== 'view' && !isOutdated"
                @click="removeLinkItem(link)"
                class="el-icon-circle-close links__delete"
              ></i>
              <div class="links__text">
                <a target="_blank" :href="link">{{ link }}</a>
              </div>
            </div>
          </div>
        </div>
        <div v-if="modalType === 'view' || isOutdated" class="named-input">
          <div class="named-input__label">Создатель совещания</div>
          <div class="creator">
            <img
              :src="
                creator.image
                  ? 'https://mirtek.info:22334/uploads/' + creator.image
                  : 'https://mirtek.info:22334/portal/img/blank-face-person.83c30568.png'
              "
              :alt="creator.surname + ' ' + creator.name"
              class="creator__img"
            />
            <div class="creator__name">
              <div>{{ creator.surname }}</div>
              <div>{{ creator.name }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer">
      <span
        v-if="modalType === 'edit' && initialRepeatMode === 0 && !isOutdated"
        @click="deleteMeeting(false)"
        v-loading="deletionLoading"
        :disabled="deletionLoading || submitLoading"
        class="footer__delete"
        :class="deletionLoading || submitLoading ? 'footer__delete--disabled' : ''"
        >Удалить</span
      >
      <el-dropdown
        @command="deleteMeeting"
        v-if="modalType === 'edit' && initialRepeatMode !== 0 && !isOutdated"
      >
        <span
          v-loading="deletionLoading"
          class="footer__delete"
          :class="deletionLoading || submitLoading ? 'footer__delete--disabled' : ''"
        >
          Удалить<i class="el-icon-arrow-down el-icon--right"></i>
        </span>
        <el-dropdown-menu
          :class="deletionLoading || submitLoading ? 'footer__delete--disabled' : ''"
          slot="dropdown"
        >
          <el-dropdown-item :command="false">Только это</el-dropdown-item>
          <el-dropdown-item :command="true">Это и все последующие</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <button
        :disabled="deletionLoading || submitLoading"
        :class="deletionLoading || submitLoading ? 'footer__button--disabled' : ''"
        @click="closeCreateModal"
        class="footer__button--cancel footer__button"
      >
        {{ modalType === 'view' || isOutdated ? 'ЗАКРЫТЬ' : 'ОТМЕНА' }}
      </button>
      <button
        v-if="modalType === 'create'"
        @click="onSaveCreateClick(false)"
        :disabled="!valuesChanged || submitLoading"
        v-loading="submitLoading"
        :class="
          !valuesChanged || submitLoading || deletionLoading ? 'footer__button--disabled' : ''
        "
        class="footer__button--save footer__button"
      >
        СОХРАНИТЬ
      </button>
      <el-tooltip
        v-if="modalType === 'edit'"
        class="item"
        effect="dark"
        content="Не уведомлять"
        placement="top"
      >
        <button
          v-if="modalType !== 'view' && !isOutdated"
          @click="onSaveCreateClick(false)"
          :disabled="!valuesChanged || submitLoading"
          v-loading="submitLoading"
          :class="
            !valuesChanged || submitLoading || deletionLoading ? 'footer__button--disabled' : ''
          "
          class="footer__button--save footer__button footer__button--nonotification"
        >
          {{ modalType === 'edit' && !isOutdated ? 'СОХРАНИТЬ' : 'СОЗДАТЬ' }}
          <el-icon class="el-icon-bell footer__bell footer__bell--nonotification "></el-icon>
        </button>
      </el-tooltip>
      <el-tooltip
        v-if="modalType === 'edit'"
        class="item"
        effect="dark"
        content="Уведомить всех"
        placement="top"
      >
        <button
          v-if="modalType === 'edit'"
          @click="onSaveCreateClick(true)"
          :disabled="!valuesChanged || submitLoading"
          v-loading="submitLoading"
          :class="
            !valuesChanged || submitLoading || deletionLoading ? 'footer__button--disabled' : ''
          "
          class="footer__button--save footer__button"
        >
          {{ modalType === 'edit' && !isOutdated ? 'СОХРАНИТЬ' : 'СОЗДАТЬ' }}
          <el-icon class="el-icon-bell footer__bell"></el-icon>
        </button>
      </el-tooltip>
    </div>
    <repeat-custom
      v-if="isRepeatModal"
      @cancelRepeat="handleCancelRepeat"
      @saveRepeat="handleCustomRepeatSave"
      :customSettings="customSettings"
      :meetingDate="dateSelected"
    ></repeat-custom>
  </div>
</template>
<script>
import axios from 'axios'
import store from '../store'
import RepeatCustom from './RepeatCustom.vue'

import Message from 'element-ui/lib/message'

export default {
  components: {
    RepeatCustom
  },
  props: {
    meeting: {
      type: Object,
      required: false
    },
    meetingId: {
      type: Number,
      required: false
    },
    typeOfModal: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      initialValues: null,
      valuesChanged: false,
      initialDateStart: null,
      id: null,
      title: '',
      description: '',
      dateSelected: '',
      timeFrom: '',
      timeTo: '',
      connectionLink: '',
      meetingPlace: '',
      remindMode: null,
      initialRepeatMode: null,
      remindModes: [],
      repeatMode: null,
      repeatModes: [],
      repeatEndCycle: '', // string for backend
      isEditGroup: false,
      isOutdated: false,
      notificateAll: false,
      test: false,
      test2: false,

      test2: false,
      
      test2: false,
      test2: false,


      isRepeatModal: false,
      selectedUsers: [],
      selectedUserIds: [],
      searchUserValue: '',

      isFileDrag: false,
      files: [],
      filesIds: [],
      uploadedFiles: [],
      fileNames: [],

      linkValue: '',
      linksList: [],
      creator: {},
      customSettings: '',

      deletionLoading: false,
      submitLoading: false
    }
  },

  methods: {
    handleCancelRepeat() {
      this.repeatMode = this.repeatModes[0].value
      this.isRepeatModal = false
    },
    handleCustomRepeatSave(settings) {
      // TODO contract with backend
      this.customSettings = settings
      this.isRepeatModal = false
      if (!settings.repeatUntil) return
      this.repeatEndCycle = new Date(settings.repeatUntil).toISOString()
    },
    checkCustomSettings() {
      if (this.repeatMode == 6) this.isRepeatModal = true
    },

    onSaveCreateClick(notificate) {
      this.notificateAll = notificate
      this.submitLoading = true
      if (this.modalType === 'create') this.createMeeting()
      if (this.modalType === 'edit') this.editMeeting()
    },

    onUserClick(user) {
      if (!this.selectedUserIds.includes(user.id)) {
        this.selectedUsers.push(user)
        this.selectedUserIds.push(user.id)
      } else {
        this.selectedUsers = this.selectedUsers.filter(el => el.id !== user.id)
        this.selectedUserIds.splice(this.selectedUserIds.indexOf(user.id), 1)
      }
    },

    filteredUsers() {
      let input = this.searchUserValue.toLowerCase().trim()
      let words = input.split(' ')

      let filteredUsers = this.usersPortal.filter(user => !this.selectedUserIds.includes(user.id))

      if (input === '') return filteredUsers
      return filteredUsers.filter(user => {
        return words.every(el => {
          return (
            user.name
              .toLowerCase()
              .trim()
              .includes(el) ||
            user.surname
              .toLowerCase()
              .trim()
              .includes(el)
          )
        })
      })
    },

    async getRemindModes() {
      try {
        this.remindModes = await axios.get('get-list-reminds-modes').then(res => res.data)
        store.commit('setRemindModes', this.remindModes)
        this.setRemindMode()
      } catch (error) {
        console.error(error)
      }
    },
    setRemindMode() {
      this.remindModes = store.state.remindModes

      if (this.modalType === 'create') this.remindMode = this.remindModes[0].value
      else {
        this.remindMode = this.remindModes.find(
          mode => +mode.value == this.meeting.remind_mode_id
        ).value
        this.remindMode = this.remindModes.find(mode => mode.value === this.remindMode).value
      }
    },

    async getRepeatModes() {
      try {
        this.repeatModes = await axios.get('get-list-repeats-modes').then(res => res.data)
        store.commit('setRepeatModes', this.repeatModes)
        this.setRepeatMode()
      } catch (error) {
        console.error(error)
      }
    },
    setRepeatMode() {
      this.repeatModes = store.state.repeatModes
      if (this.modalType === 'create') this.repeatMode = this.repeatModes[0].value
      else {
        this.repeatMode = this.repeatModes.find(
          mode => mode.value === this.meeting.repeat_mode_id
        ).value
      }
    },
    validateFields() {
      let errors = []
      let errorMessage = ''

      if (this.title.trim() === '') errors.push('Введите тему совещания')
      // if (this.selectedUserIds.length < 2) errors.push('Выберите 2 или больше участников')
      if (this.selectedUserIds.length < 1) errors.push('Выберите 1 или больше участников')
      if (this.dateSelected === '') errors.push('Выберите дату совещания')
      if (!this.timeFrom) errors.push('Выберите время начала совещания')
      if (!this.timeTo) errors.push('Выберите время конца совещания')

      let h = this.$createElement

      errorMessage = errors.join('\n')
      if (errors.length > 0) {
        Message.error({
          message: h('p', { style: 'white-space: pre-line' }, [
            h(
              'span',
              {
                style: 'font-weight: 700; font-size: 18px; padding-bottom: 8px;'
              },
              'Введите обязательные поля\n'
            ),
            h('span', null, errorMessage)
          ]),
          duration: 5000,
          showClose: true
        })
      }

      return errors.length === 0
    },

    fixDates() {
      let tempFrom = new Date(this.timeFrom)
      let tempDate = new Date(this.dateSelected)
      tempDate.setHours(tempFrom.getHours())
      tempDate.setMinutes(tempFrom.getMinutes())
      tempDate.setSeconds(tempFrom.getSeconds())

      let date = tempDate.toISOString().split('T')[0]
      let timeFrom = date + 'T' + new Date(this.timeFrom).toISOString().split('T')[1]
      let timeTo = date + 'T' + new Date(this.timeTo).toISOString().split('T')[1]

      return [timeFrom, timeTo]
    },

    appendToFormdata() {
      let formData = new FormData()
      let [timeFrom, timeTo] = this.fixDates()

      for (let i = 0; i < this.uploadedFiles.length; i++) {
        if (this.uploadedFiles[i]) {
          formData.append(`files`, this.uploadedFiles[i])
        }
      }
      for (let i = 0; i < this.selectedUserIds.length; i++) {
        if (this.selectedUserIds[i]) {
          formData.append(`user_ids[${i}]`, this.selectedUserIds[i])
        }
      }
      for (let i = 0; i < this.linksList.length; i++) {
        if (this.linksList[i]) {
          formData.append(`links_documents[${i}]`, this.linksList[i])
        }
      }
      if (this.modalType === 'edit') {
        formData.append('id', this.id)
        formData.append('datetime_initial', this.initialDateStart)
        if (this.filesIds.length !== 0) {
          for (let i = 0; i < this.filesIds.length; i++) {
            if (this.filesIds[i]) {
              formData.append(`files_ids[${i}]`, this.filesIds[i])
            }
          }
        }
      }

      formData.append('name', this.title)
      if (this.description) formData.append('description', this.description)
      if (this.connectionLink) formData.append('link_meeting', this.connectionLink)
      formData.append('datetime_start', timeFrom)
      formData.append('datetime_end', timeTo)
      formData.append('datetime_end_cycle', this.repeatEndCycle === null ? '' : this.repeatEndCycle)

      formData.append('repeat_mode_id', this.repeatMode)
      if (this.repeatMode === 6) {
        formData.append('custom_settings', JSON.stringify(this.customSettings))
      }
      formData.append('remind_mode_id', this.remindMode)
      if (this.modalType === 'edit') {
        formData.append('is_notifications_requested', this.notificateAll)
        formData.append('is_edit_group', this.isEditGroup)
      }
      if (this.meetingPlace) formData.append('place', this.meetingPlace)

      return formData
    },

    async editMeeting() {
      if (!this.validateFields()) return (this.submitLoading = false)

      let formData = this.appendToFormdata()

      try {
        await axios({
          method: 'post',
          url: `edit-meeting`,
          data: formData,
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
        Message.success({
          message: `Изменения успешно сохранены`,
          duration: 2000,
          showClose: true
        })

        this.$root.$emit('meetingChange', 'edit')
        this.closeCreateModal()
      } catch (error) {
        console.error(error)
        let errorMessage = error.response.data ? error.response.data : error.response.message
        this.showError(`Ошибка при редактировании совещания: ${errorMessage}`)
      } finally {
        this.submitLoading = false
      }
    },
    async createMeeting() {
      if (!this.validateFields()) return (this.submitLoading = false)

      let formData = this.appendToFormdata()

      try {
        await axios({
          method: 'post',
          url: `create-task-meetings`,
          data: formData,
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
        Message.success({
          message: `Совещание успешно создано`,
          duration: 2000,
          showClose: true
        })

        this.$root.$emit('meetingChange', 'create')
        this.closeCreateModal()
      } catch (error) {
        let errorMessage = error.response.data ? error.response.data : error.response.message
        console.error(error, 'error')
        this.showError(`Ошибка при создании совещания: ${errorMessage}`)
      } finally {
        this.submitLoading = false
      }
    },
    async deleteMeeting(isGrouply) {
      if (this.deletionLoading || this.submitLoading) return

      this.deletionLoading = true
      let formData = new FormData()
      let [timeFrom] = this.fixDates()
      formData.append('id', this.id)
      formData.append('is_delete_group', isGrouply)
      formData.append('datetime_start', timeFrom)

      try {
        await axios({
          method: 'post',
          url: `delete-meeting`,
          data: formData
        })
        Message.success({
          message: `Совещание успешно удалено`,
          duration: 2000,
          showClose: true
        })

        this.$root.$emit('meetingChange', 'delete')
        this.closeCreateModal()
      } catch (error) {
        let errorMessage = error.response.data ? error.response.data : error.response.message
        this.showError(`Ошибка при удалении совещания: ${errorMessage}`)
      } finally {
        this.deletionLoading = false
      }
    },

    closeCreateModal() {
      this.$emit('close')
    },

    showError(text, duration = 4000, showClose = true) {
      Message.error({
        message: text,
        duration: duration,
        showClose: showClose
      })
    },

    // Files
    dragenterHandler(e) {
      if (!e.dataTransfer.types.includes('Files')) return
      this.isFileDrag = true
    },
    dragleaveHandler() {
      setTimeout(() => (this.isFileDrag = false), 100)
    },

    clickOnUpload() {
      this.$refs.actionsUpload.click()
    },

    handleFilesUpload(e) {
      let files
      if (e.type === 'drop') files = e.dataTransfer.files
      if (e.type === 'input') files = e.srcElement.files

      // check that the files are no larger than 5 MB
      const dt = new DataTransfer()

      files = this.filterByFileSize(files)

      for (let i = 0; i < files.length; i++) {
        dt.items.add(files[i])
      }

      this.isFileDrag = false
      if (!files.length) return
      this.addFiles(dt.files)
    },

    filterByFileSize(files) {
      let filesArray = [...files]
      const passedFiles = []
      const maxSize = 5 * 1024 * 1024 // 5 MB
      const notPassedFileNames = []

      for (let i = 0; i < files.length; i++) {
        let file = files[i]

        if (file.size < maxSize) passedFiles.push(file)
        else {
          notPassedFileNames.push(file.name)
          filesArray.splice(i, 1)
        }
      }

      if (notPassedFileNames.length > 0) {
        this.showError(
          `Файлы не были добавлены, так как их размер превышает ${maxSize /
            1024 /
            1024} МБ: ${notPassedFileNames.join(', ')}`
        )
      }

      return filesArray
    },

    addFiles(argFiles) {
      argFiles = [...argFiles]

      let existingFilesError = []

      argFiles.forEach(file => {
        if (!this.fileNames.includes(file.name)) {
          this.uploadedFiles.push(file)
          this.fileNames.push(file.name)
          this.files.push({
            name: file.name
          })
        } else existingFilesError.push(file.name)
      })

      if (existingFilesError.length > 0) {
        this.showError(
          `Файлы не были добавлены, так как они уже присутствуют: ${existingFilesError.join(', ')}`
        )
      }
    },

    removeFile(file) {
      this.files = this.files.filter(el => el.name !== file.name)
      this.filesIds = this.filesIds.filter(id => id !== file.id)
      this.uploadedFiles = [...this.uploadedFiles].filter(el => el.name !== file.name)
      this.fileNames = this.files.filter(el => el.name !== file.name)
    },

    async downloadFile(file) {
      const link = document.createElement('a')
      document.body.append(link)
      link.target = '_blank'
      try {
        await axios.get(`download-file?id=${file.id}`).then(res => {
          let data = res.data
          link.href = data.content
          link.download = data.name
          link.click()

          link.remove()
        })
      } catch (error) {
        console.error(error)
      }
    },

    // !Upload files

    formatPeriod() {
      const months = [
        'Января',
        'Февраля',
        'Марта',
        'Апреля',
        'Мая',
        'Июня',
        'Июля',
        'Августа',
        'Сентября',
        'Октября',
        'Ноября',
        'Декабря'
      ]

      const timeFrom = new Date(this.meeting.datetime_start)
      const timeTo = new Date(this.meeting.datetime_end)

      let start =
        timeFrom.getHours().toString() +
        ':' +
        timeFrom
          .getMinutes()
          .toString()
          .padStart(2, '0')

      let end =
        timeTo.getHours().toString() +
        ':' +
        timeTo
          .getMinutes()
          .toString()
          .padStart(2, '0')

      let period = `${start} - ${end}`

      const day = timeFrom.getDate().toString() + ' ' + months[timeFrom.getMonth()]
      return [day, period]
    },

    validateLink(link) {
      let pattern = new RegExp(
        '^(https?:\\/\\/)?' + // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
        '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
        '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
          '(\\#[-a-z\\d_]*)?$',
        'i'
      ) // fragment locator

      return !!pattern.test(link.trim())
    },

    addLinkItem() {
      let link = this.linkValue.trim()

      if (!this.validateLink(this.linkValue)) {
        return this.showError({
          text: 'Проверьте правильность ссылки',
          duration: 2000
        })
      }
      if (this.linksList.includes(link)) {
        return this.showError({
          text: 'Такая ссылка уже присутствует',
          duration: 2000
        })
      } else {
        this.linksList.push(link)
        this.linkValue = ''
      }
    },
    removeLinkItem(link) {
      this.linksList = this.linksList.filter(el => el !== link)
    },
    disabledDates(date) {
      const today = new Date()
      today.setHours(0, 0, 0, 0)

      return date < today
    },
    disabledRepeatDates(date) {
      let meetingDate = new Date(this.timeFrom)
      meetingDate.setHours(0, 0, 0, 0)
      return meetingDate > date
    },
    selectableTimes() {
      const today = new Date()

      let minHoursTo = today.getHours()
      let minMinutesTo = today.getMinutes()

      if (this.timeFrom) {
        // 54 - hardcoded value of max minutes until hour will be incremented
        minHoursTo =
          this.timeFrom.getMinutes() <= 54 ? this.timeFrom.getHours() : this.timeFrom.getHours() + 1
        minMinutesTo = this.timeFrom.getMinutes() <= 54 ? this.timeFrom.getMinutes() + 5 : 5
      }

      if (this.dateSelected && this.isToday(this.dateSelected)) {
        const minHoursFrom = today.getHours()
        const minMinutesFrom = today.getMinutes()

        return [
          `${minHoursFrom}:${minMinutesFrom}:00 - 23:59:00`,
          `${minHoursTo}:${minMinutesTo}:00 - 23:59:00`
        ]
      } else return ['00:00:00 - 23:59:00', '00:00:00 - 23:59:00']
    },
    resetTimes() {
      this.timeTo = null
      this.timeFrom = null
      // TODO
      // this.repeatMode = 0
      // this.repeatEndCycle = ''
    },
    isToday(date) {
      const today = new Date()

      return (
        date.getDate() == today.getDate() &&
        date.getMonth() == today.getMonth() &&
        date.getFullYear() == today.getFullYear()
      )
    },
    setInitialValues() {
      const m = this.meeting

      this.initialValues = JSON.stringify({
        title: m.name,
        id: m.id,
        description: m.description,
        dateSelected: new Date(m.datetime_start),
        timeFrom: new Date(m.datetime_start),
        initialDateStart: m.datetime_start,
        timeTo: new Date(m.datetime_end),
        connectionLink: m.link_meeting,
        selectedUserIds: m.user_ids,
        meetingPlace: m.place,
        files: m.files,
        filesIds: [...m.files_ids],
        linksList: [...m.links_documents],
        selectedUsers: this.usersPortal.filter(user => m.user_ids.includes(user.id)),
        remindMode: m.remind_mode_id,
        repeatMode: m.repeat_mode_id,
        repeatEndCycle: m.datetime_end_cycle,
        isOutdated: m.isOutdated,
        customSettings: m.custom_settings
      })
    },

    setMeetingData() {
      const m = this.meeting
      this.title = m.name
      this.id = m.id
      this.description = m.description
      this.dateSelected = new Date(m.datetime_start)
      this.timeFrom = new Date(m.datetime_start)
      this.initialDateStart = m.datetime_start
      this.timeTo = new Date(m.datetime_end)
      this.connectionLink = m.link_meeting
      this.selectedUserIds = m.user_ids
      this.meetingPlace = m.place
      this.files = m.files
      this.fileNames = m.files.map(file => file.name)
      this.filesIds = [...m.files_ids]
      this.linksList = [...m.links_documents]

      this.selectedUsers = this.usersPortal.filter(user => m.user_ids.includes(user.id))
      this.remindMode = m.remind_mode_id
      this.repeatMode = m.repeat_mode_id
      this.initialRepeatMode = m.repeat_mode_id
      this.repeatEndCycle = m.datetime_end_cycle
      this.isOutdated = m.isOutdated

      this.customSettings = m.custom_settings ? JSON.parse(m.custom_settings) : null

      if (this.modalType === 'view')
        this.creator = this.usersPortal.find(user => m.user_id === user.id)
      this.setInitialValues()
    },
    openSharedMeeting() {
      const m = this.meeting

      this.title = m.name
      this.id = m.id
      this.description = m.description
      this.dateSelected = new Date(m.datetime_start)
      this.timeFrom = new Date(m.datetime_start)
      this.initialDateStart = m.datetime_start
      this.timeTo = new Date(m.datetime_end)
      this.connectionLink = m.link_meeting
      this.selectedUserIds = m.user_ids
      this.meetingPlace = m.place
      this.files = m.files
      this.fileNames = m.files.map(file => file.name)
      this.filesIds = [...m.files_ids]
      this.linksList = [...m.links_documents]

      this.selectedUsers = this.usersPortal.filter(user => m.user_ids.includes(user.id))
      this.remindMode = m.remind_mode_id
      this.repeatMode = m.repeat_mode_id
      this.initialRepeatMode = m.repeat_mode_id
      this.repeatEndCycle = m.datetime_end_cycle
      this.isOutdated = m.isOutdated

      this.customSettings = m.custom_settings ? JSON.parse(m.custom_settings) : ''
      this.creator = this.usersPortal.find(user => m.user_id === user.id)
      this.setInitialValues()
    }
  },

  watch: {
    meeting() {
      this.setMeetingData()
    },
    currentValues: {
      handler(newValue) {
        return (this.valuesChanged = JSON.stringify(newValue) !== this.initialValues)
      }
    },
    timeFrom(value) {
      if (!value) return
      return value.setSeconds(0)
    },
    timeTo(value) {
      if (!value) return
      return value.setSeconds(0)
    }
  },

  computed: {
    usersPortal() {
      return store.state.usersPortal
    },
    canCreate() {
      return store.state.user.permissions.includes(1)
    },
    modalType() {
      if (!this.meeting) return 'create'

      if (this.isOutdated || !this.canCreate) return 'view'
      else return 'edit'
    },
    currentValues() {
      return {
        title: this.title,
        id: this.id,
        description: this.description,
        dateSelected: this.dateSelected,
        timeFrom: this.timeFrom,
        initialDateStart: this.initialDateStart,
        timeTo: this.timeTo,
        connectionLink: this.connectionLink,
        selectedUserIds: this.selectedUserIds,
        meetingPlace: this.meetingPlace,
        files: this.files,
        filesIds: this.filesIds,
        linksList: this.linksList,
        selectedUsers: this.selectedUsers,
        remindMode: this.remindMode,
        repeatMode: this.repeatMode,
        repeatEndCycle: this.repeatEndCycle,
        isOutdated: this.isOutdated,
        customSettings: this.customSettings ? JSON.stringify(this.customSettings) : ''
      }
    }
  },

  mounted() {
    if (store.state.remindModes.length === 0) this.getRemindModes()
    else this.setRemindMode()

    if (store.state.repeatModes.length === 0) this.getRepeatModes()
    else this.setRepeatMode()

    if (this.$route.name === 'meeting-id') {
      return this.openSharedMeeting()
    }
    if (this.modalType === 'create') {
      this.selectedUsers = [this.usersPortal.find(user => user.id === store.state.user.data.id)]
      this.selectedUserIds = [store.state.user.data.id]
    }

    if (this.meeting && this.modalType !== 'create') {
      this.setMeetingData()
    }
  }
}
</script>
<style lang="scss" scoped>
.create {
  position: relative;
  display: flex;
  flex-flow: column;
  height: 89vh;
  min-height: 300px;
  max-width: 1370px;
  min-width: 600px;
  width: 100%;
  background: var(--c-body);
  color: var(--c-text);
  border-radius: 20px;
  z-index: 30;

  &__header {
    flex: 0 1 auto;
    padding: 10px 20px;
    border-bottom: 1px solid var(--c-border);
  }
  &__title {
    font-size: 24px;
    font-weight: 400;
  }
  &__body {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    flex: 1;
    height: 400px;
    padding: 0 10px;
  }
  &_column {
    display: flex;
    flex-direction: column;
    padding: 20px 10px 20px;
    overflow-y: auto;
    overflow-x: hidden;
    border-right: 1px solid var(--c-border);
    &:last-child {
      border-right: none;
      padding-right: 0;
    }
    &::-webkit-scrollbar {
      height: 9px;
      width: 9px;
    }
    &::-webkit-scrollbar-track {
      background: var(--c-border);
      border-radius: 10px;
    }

    &::-webkit-scrollbar-thumb {
      background: var(--c-divider);
      border-radius: 10px;
    }
  }
}

.modal-input {
  height: 40px;
  width: 100%;
  background: var(--c-elem-highlight);
  border: 1px solid var(--c-border);
  padding: 0 15px;
  color: var(--c-text);
  font-size: 14px;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  border-radius: 4px;
  outline: 0;
  line-height: 40px;
  &:focus {
    border: 1px solid var(--c-outline);
  }
  &:hover:not(:focus) {
    border: 1px solid var(--c-border-hover);
  }
}

.modal-link {
  color: #5faefd;
  font-size: 16px;
  line-height: 14px;
  white-space: nowrap;
  &--connection {
    margin-top: 20px;
    // padding-right: 20px;
    margin-left: 20px;
    & > .modal-link-icon {
      margin-left: 5px;
    }
  }
}

.footer {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  height: 40px;

  flex: 0 1 40px;
  padding: 10px 20px 10px 20px;
  border-top: 1px solid var(--c-border);
  gap: 10px;
  &__delete {
    margin-right: 20px;
    color: red;
    cursor: pointer;
    &:not(.footer__button--disabled):hover {
      color: #e43b3b;
    }
    &--disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  }
  &__button {
    height: 30px;
    border: transparent;
    border-radius: 3px;
    color: var(--c-button-text);
    padding: 0 15px;
    transition: 0.1s background linear;
    cursor: pointer;
    &--disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    &--save {
      background: var(--c-button-success);
      &:not(.footer__button--disabled):hover {
        background: var(--c-button-success-hover);
      }
    }
    &--cancel {
      background: var(--c-button-cancel);
      &:not(.footer__button--disabled):hover {
        background: var(--c-button-cancel-hover);
      }
    }
    &--nonotification {
      margin-left: 14px;
    }
  }
  &__bell {
    position: relative;
    margin-left: 10px;
    &--nonotification {
      &::after {
        content: '';
        position: absolute;
        top: -2px;
        right: 5px;
        height: 17px;
        width: 2px;
        background: red;
        rotate: 45deg;
      }
    }
  }
}

.confirm-overlay {
  position: absolute;
  top: -4000px;
  left: -4000px;
  right: -4000px;
  bottom: -4000px;
  background: rgba(0, 0, 0, 0.4);
  border-radius: 20px;
}

.confirm-edit {
  display: flex;
  flex-direction: column;
  position: absolute;
  top: 50%;
  right: 50%;
  bottom: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  padding: 15px;
  z-index: 1000;
  background: var(--c-bg);
  border: 1px solid var(--c-border);
  height: 200px;
  width: 675px;
  border-radius: 6px;
  &__header {
    margin-bottom: 10px;
  }
  &__footer {
    margin-top: auto;
  }
  &__title {
    font-size: 26px;
  }
  &__description {
    font-size: 14px;
    color: var(--c-text-mute);
    padding-left: 15px;
  }
  &__item {
    position: relative;
    margin-bottom: 6px;
    color: var(--c-text-mute);
    &::before {
      content: '';
      position: absolute;
      left: -15px;
      transform: translateY(60%);
      width: 6px;
      height: 6px;
      border-radius: 100%;
      background: var(--c-outline);
    }
  }
  &__buttons {
    display: flex;
    justify-content: flex-end;
    align-items: flex-end;
    gap: 10px;
  }
  &__button {
    color: var(--c-button-text);
    background: var(--c-button-success);

    &:hover {
      background: var(--c-button-success-hover);
    }
    &--cancel {
      background: var(--c-button-cancel);
      margin-right: auto;
      &:hover {
        background: var(--c-button-cancel);
      }
    }
  }
}

.upload {
  display: flex;
  flex-direction: column;
  &__dropdown {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    border: 1px dashed var(--c-border-hover);
    padding: 20px;
    padding-top: 10px;
    width: 100%;
    margin-bottom: 20px;
    border-radius: 2px;
    background: var(--c-elem-highlight);
    transition: background 0.1s ease-in-out, border 0.1s ease-in-out;
    cursor: pointer;
    &.dragover {
      background: var(--c-elem-hover);
      border: 1px dashed #247dd5;
    }
    &:hover {
      border: 1px dashed #5faefd;
    }
  }
  &__text {
    color: var(--c-text);
    &-click {
      display: inline;
      color: #5faefd;
      cursor: pointer;
    }
  }
  &__icon {
    font-size: 40px;
    color: #c2c2c2;
  }
  &__notice {
    padding-top: 5px;
    color: var(--c-text-mute);
  }
}

.files {
  overflow-y: auto;
  max-height: 120px;
  margin-bottom: 20px;
  &::-webkit-scrollbar {
    height: 6px;
    width: 6px;
  }
  &::-webkit-scrollbar-track {
    background: var(--c-border);
    border-radius: 10px;
  }

  &::-webkit-scrollbar-thumb {
    background: var(--c-divider);
    border-radius: 10px;
  }
  &__file {
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
    padding: 4px 0;

    &:hover {
      .files__delete {
        display: block;
      }
    }
  }
  &__icon {
    font-size: 16px;
    margin-right: 5px;
    cursor: pointer;
  }
  &__filename {
    width: calc(100% - 30px);
    font-size: 14px;
    cursor: pointer;
    &-text {
      width: 100%;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
  &--empty {
    margin-bottom: 20px;
  }

  &__delete {
    position: absolute;
    right: 10px;
    top: 5px;
    display: none;
    color: #e43b3b;
    margin-left: 20px;
    font-size: 16px;
    cursor: pointer;
  }
}

.links {
  display: flex;
  flex-direction: column;
  overflow: auto;
  &__row {
    margin-bottom: 10px;
    gap: 5px;
  }
  &__input {
    height: 40px;
    width: 100%;
    background: var(--c-elem-highlight);
    border: 1px solid var(--c-border);
    padding: 0 15px;
    color: var(--c-text);
    font-size: 14px;
    transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
    border-radius: 4px;
    outline: 0;
    line-height: 40px;
    &:focus {
      border: 1px solid var(--c-outline);
    }
    &:hover:not(:focus) {
      border: 1px solid var(--c-border-hover);
    }
  }
  &__list {
    padding: 0 20px 10px 0;
    overflow-y: auto;
    overflow-x: hidden;
    &::-webkit-scrollbar {
      height: 6px;
      width: 6px;
    }
    &::-webkit-scrollbar-track {
      background: var(--c-border);
      border-radius: 10px;
    }

    &::-webkit-scrollbar-thumb {
      background: var(--c-divider);
      border-radius: 10px;
    }
  }
  &__item {
    position: relative;
    width: 100%;
    padding: 4px 0;
    &:hover {
      .links__delete {
        opacity: 1;
      }
    }
  }
  &__text {
    white-space: nowrap;
    text-overflow: ellipsis;
    & > a {
      color: #5faefd;
      font-size: 16px;
    }

    overflow: hidden;
  }
  &__delete {
    opacity: 0;
    position: absolute;
    color: #e43b3b;
    right: -12px;
    font-size: 16px;
    top: 4px;
    transition: 0.1s opacity linear;
    cursor: pointer;
  }
  &__add {
    height: 40px;
    width: 100%;
    max-width: 100px;
    border: none;
    border-radius: 4px;
    background: var(--c-elem-highlight);
    color: var(--c-text);
    border: 1px solid var(--c-border);
    transition: 0.1s background linear;
    cursor: pointer;

    &:hover {
      background: var(--c-elem-highlight);
    }

    &[disabled] {
      background: var(--c-elem-disabled);
      cursor: not-allowed;
    }
  }
}

.row {
  display: flex;
  align-items: center;
  width: 100%;
}

.gap {
  gap: 10px;
}

.space-between {
  display: flex;
  justify-content: space-between;
}

.cell {
  height: 50%;
  overflow: auto;
  &_height {
    height: 100%;
  }
}
.pb-20 {
  padding-bottom: 20px;
}
.required-field {
  color: red;
}

.named-input {
  display: flex;
  flex-direction: column;
  column-gap: 20px;
  &__label {
    display: inline;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: var(--c-text-label);
    font-size: 13px;
    margin-bottom: 4px;
  }
  &__text {
    color: var(--c-text);
  }
  &__wrapper {
    display: flex;
    flex-direction: column;
  }
  &__textarea {
    color: var(--c-text);
    background: var(--c-elem-highlight);
    border: 1px solid var(--c-border);
    &:hover {
      border: 1px solid var(--c-border-hover);
    }

    &::-webkit-scrollbar {
      height: 6px;
      width: 6px;
    }
    &::-webkit-scrollbar-track {
      background: var(--c-border);
      border-radius: 10px;
    }

    &::-webkit-scrollbar-thumb {
      background: var(--c-divider);
      border-radius: 10px;
    }
  }
  &--error {
    & > input {
      border: 1px solid #e43b3b;
      transition: 0.1s border linear;
      &:hover {
        border: 1px solid #e43b3b;
      }
    }
  }
}

.time {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 40px;
  &__divider {
    width: 20%;
    height: 1px;
    background: #dedede;
  }
}

.users {
  display: flex;
  flex-direction: column;
  row-gap: 20px;
  &__label {
    // color: #595959;
    color: var(--c-text-mute);
    margin-bottom: 5px;
  }
  &-list {
    display: flex;
    flex-direction: column;
    height: calc(100% - 19px);
    // border: 1px solid #dedede;
    background: var(--c-elem-highlight);
    border: 1px solid var(--c-border);
    border-radius: 4px;
    &__header {
      display: flex;

      // border-bottom: 1px solid #dedede;
      border-bottom: 1px solid var(--c-border-hover);
      background: var(--c-body);
      padding: 5px;
    }
    &__body {
      padding: 5px 0;
      overflow-y: auto;
      overflow-x: hidden;
      height: 100%;
      &::-webkit-scrollbar {
        height: 6px;
        width: 6px;
      }
      &::-webkit-scrollbar-track {
        background: var(--c-border);
        border-radius: 10px;
      }

      &::-webkit-scrollbar-thumb {
        background: var(--c-divider);

        border-radius: 10px;
      }
    }

    &__info {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      row-gap: 1px;
    }
    &__place {
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
      color: var(--c-text-desription);
      width: 100%;
      font-size: 10px;
    }
    &__user {
      display: flex;
      align-items: center;
      padding: 4px 10px;
      border-bottom: 1px solid var(--c-border);
      color: var(--c-text);
      background: var(--c-elem-highlight);
      transition: 0.1s background linear;
      cursor: pointer;

      &:hover {
        background: var(--c-elem-hover);
      }
      &--selected {
        background: #add6ff;
        &:hover {
          background: #a3d1ff;
        }
      }
    }
    &__photo {
      height: 30px;
      width: 30px;
      border-radius: 50%;
      margin-right: 10px;
    }
  }
}
.creator {
  display: flex;
  align-items: center;
  gap: 10px;
  &__img {
    height: 40px;
    width: 40px;
    border-radius: 50%;
  }
}

.selected {
  display: flex;
  flex-direction: column;
  border: 1px solid var(--c-border);
  background: var(--c-elem-highlight);
  border-radius: 5px;
  height: calc(100% - 50px);
  &__body {
    display: flex;
    align-items: flex-start;
    justify-content: center;
    flex-basis: content;
    flex-wrap: wrap;
    padding: 5px;

    overflow-y: auto;
    height: 100%;
    &::-webkit-scrollbar {
      height: 6px;
      width: 6px;
    }
    &::-webkit-scrollbar-track {
      background: var(--c-border);
      border-radius: 10px;
    }

    &::-webkit-scrollbar-thumb {
      background: var(--c-divider);
      border-radius: 10px;
    }
  }
  &__user {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 90px;
    height: 90px;
    padding: 4px 10px;
    transition: 0.1s background linear;
    &:hover {
      .selected__close {
        opacity: 1;
      }
    }
    &--view {
      height: 120px;
      width: 120px;
      & > img {
        height: 60px;
        width: 60px;
        margin-bottom: 5px;
      }
    }
  }
  &__close {
    opacity: 0;
    position: absolute;
    right: 10px;
    color: #e43b3b;
    font-size: 20px;
    transition: 0.1s opacity linear;
    cursor: pointer;
  }
  &__name {
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-items: center;
  }
  &__photo {
    height: 40px;
    width: 40px;
    gap: 10px;

    margin-bottom: 3px;
    border-radius: 50%;
  }
}
.datetime {
  align-items: flex-end;
  gap: 10px;
}

.view {
  &__datetime {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
  }
  &__date {
    color: var(--c-text-contrast);
  }
  &__divider {
    height: 1px;
    width: 20px;
    background: var(--c-divider);
  }
  &__time {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    font-weight: 400;
    color: var(--c-text);
  }
  &__connection-link {
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;

    & > a {
      color: #5faefd;
    }
  }
  &__text {
    font-size: 18px;
    color: var(--c-text);
    font-weight: 400;
  }
}
@media (max-width: 1305px) {
  .datetime {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
  }
  .time {
    width: 100%;
    justify-content: space-between;
  }
  .time__input[data-v-575053e4]:nth-child(2)::before {
    content: '';
  }
  .named-input {
    width: 100%;
  }
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
}
</style>
<style lang="scss">
.el-tabs__header {
  margin-bottom: 0;
}

.row.gap > .el-select > .el-input--mini .el-input__inner {
  height: 40px;
}

.row.gap > .el-select.el-select--mini > .el-select__tags {
  top: 20px;
}

.el-input--prefix .el-input__inner {
  &::placeholder {
    color: var(--c-text);
  }
}
.el-date-editor--time > .el-input__inner {
  width: 85px;
  padding-right: 0;
}
.el-date-editor.time__input.el-input.el-input--prefix.el-input--suffix.el-date-editor--time {
  width: 87px;
}

.el-input.el-input--mini.el-input--suffix {
  height: 100%;
}

.el-time-spinner__item:hover:not(.disabled).active {
  background: #f5f7fa;
  cursor: pointer;
}
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 202px;
}

.el-input-icon {
  width: 18px;
}
.el-input__suffix {
  right: 3px;
}

.el-textarea__inner {
  &::-webkit-scrollbar {
    height: 6px;
    width: 6px;
  }
  &::-webkit-scrollbar-track {
    background: var(--c-border);
    border-radius: 10px;
  }

  &::-webkit-scrollbar-thumb {
    background: var(--c-divider);
    border-radius: 10px;
  }
}

.el-tabs--card > .el-tabs__header .el-tabs__nav {
  border-radius: 20px 0 0 0;
}
.el-tabs--card > .el-tabs__header .el-tabs__item.is-active {
  border-bottom-color: #e4e7ed;
}
</style>










                                                                                                                
                                                                                                                
                                                                                        ▄ ▄                     
                                                                                    ▄   ▄▄▄     ▄ ▄▄▄ ▄ ▄       
                                                                                    █ ▄ █▄█ ▄▄▄ █ █▄█ █ █       
                                                                                 ▄▄ █▄█▄▄▄█ █▄█▄█▄▄█▄▄█ █       
                                                                               ▄ █▄▄█ ▄ ▄▄ ▄█ ▄▄▄▄▄▄▄▄▄▄▄▄▄▄    
                                                                               █▄▄▄▄ ▄▄▄ █ ▄ ▄▄▄ ▄ ▄▄▄ ▄ ▄ █ ▄  
                                                                             ▄ █ █▄█ █▄█ █ █ █▄█ █ █▄█ ▄▄▄ █ █  
                                                                             █▄█ ▄ █▄▄█▄▄█ █ ▄▄█ █ ▄ █ █▄█▄█ █  
                                                                                 █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█ █▄█▄▄▄█      
                                                                                                                
                                                                                                                
                                                                               Find File             Spc f f   
                                                                                                                
                                                                             󰈚  Recent Files          Spc f o   
                                                                                                                
                                                                             󰈭  Find Word             Spc f w   
                                                                                                                
                                                                               Bookmarks             Spc m a   
                                                                                                                
                                                                               Themes                Spc t h   
                                                                                                                
                                                                               Mappings              Spc c h   
                                                                                                                











